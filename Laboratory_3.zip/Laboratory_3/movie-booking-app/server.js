const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(bodyParser.json());

let movies = [
  { id: 1, title: "Avengers", seats: 10, image: "/images/Avengers.jpg" },
  { id: 2, title: "Inception", seats: 10, image: "/images/Inception.jpg" },
  { id: 3, title: "The Matrix", seats: 10, image: "/images/Matrix.jpg" },
  { id: 4, title: "Titanic", seats: 10, image: "/images/Titanic.jpg" }
];

let bookings = [];

// Get available movies
app.get("/movies", (req, res) => {
  res.json(movies);
});

// Book tickets
app.post("/book", (req, res) => {
  const { movieId, customerName, numberOfSeats } = req.body;

  const movie = movies.find((m) => m.id === parseInt(movieId)); // Corrected movie ID parsing

  if (!movie) {
    return res.status(404).json({ message: "Movie not found" });
  }

  const seatsToBook = parseInt(numberOfSeats);

  if (isNaN(seatsToBook) || seatsToBook <= 0) {
    return res.status(400).json({ message: "Invalid number of seats" });
  }

  if (movie.seats < seatsToBook) {
    return res.status(400).json({ message: `Only ${movie.seats} seat(s) available` });
  }

  movie.seats -= seatsToBook;

  const booking = {
    id: bookings.length + 1,
    movieTitle: movie.title,
    customerName,
    numberOfSeats: seatsToBook
  };

  bookings.push(booking);

  res.json({
    message: `Successfully booked ${seatsToBook} seat(s) for ${movie.title} under ${customerName}`,
    booking
  });
});

// View bookings
app.get("/bookings", (req, res) => {
  res.json(bookings);
});

// Cancel booking
app.delete("/cancel/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = bookings.findIndex((b) => b.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Booking not found" });
  }

  const cancelledBooking = bookings[index];
  const movie = movies.find((m) => m.title === cancelledBooking.movieTitle);

  if (movie) {
    movie.seats += cancelledBooking.numberOfSeats;
  }

  bookings.splice(index, 1);

  res.json({ message: "Booking cancelled", booking: cancelledBooking });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
