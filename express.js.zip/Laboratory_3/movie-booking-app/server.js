// Import required modules
const express = require("express");
const bodyParser = require("body-parser");

// Create an instance of an Express application
const app = express();
const PORT = 3000; // Define the port number for the server

// Middleware
app.use(express.static("public")); // Serve static files from the "public" directory
app.use(bodyParser.json()); // Parse incoming JSON requests

// Sample data: List of movies available for booking
let movies = [
    {
      id: 1,
      title: "Avengers",
      seats: 5, // Number of available seats
      image: "/images/Avengers.jpg" // Path to the movie image
    },
    {
      id: 2,
      title: "Inception",
      seats: 5,
      image: "/images/Inception.jpg"
    },
    {
      id: 3,
      title: "The Matrix",
      seats: 5,
      image: "/images/Matrix.jpg"
    },
    {
        id: 4,
        title: "Titanic",
        seats: 5,
        image: "/images/Titanic.jpg"
    }
];

// Array to store bookings
let bookings = [];

// ✅ GET /movies → List available movies
app.get("/movies", (req, res) => {
  res.json(movies); // Send the list of movies as a JSON response
});

// ✅ POST /book → Book a ticket
app.post("/book", (req, res) => {
  const { movieId, customerName } = req.body; // Extract movieId and customerName from the request body

  // Find the movie by its ID
  const movie = movies.find((m) => m.id === movieId);
  if (!movie) {
    return res.status(404).json({ message: "Movie not found" }); // Return 404 if movie not found
  }

  // Check if there are available seats
  if (movie.seats <= 0) {
    return res.status(400).json({ message: "No seats available" }); // Return 400 if no seats are available
  }

  // Decrease the number of available seats
  movie.seats -= 1;

  // Create a new booking object
  const booking = {
    id: bookings.length + 1, // Unique ID for the booking
    movieTitle: movie.title, // Title of the booked movie
    customerName, // Name of the customer
  };

  bookings.push(booking); // Add the booking to the bookings array

  // Send a success response with booking details
  res.json({ message: `Booked ${movie.title} for Customer: ${customerName}`, booking });
});

// ✅ GET /bookings → View all booked tickets
app.get("/bookings", (req, res) => {
  res.json(bookings); // Send the list of bookings as a JSON response
});

// ✅ DELETE /cancel/:id → Cancel a booking
app.delete("/cancel/:id", (req, res) => {
  const id = parseInt(req.params.id); // Get the booking ID from the request parameters
  const index = bookings.findIndex((b) => b.id === id); // Find the index of the booking

  if (index === -1) {
    return res.status(404).json({ message: "Booking not found" }); // Return 404 if booking not found
  }

  const cancelledBooking = bookings[index]; // Get the cancelled booking
  const movie = movies.find((m) => m.title === cancelledBooking.movieTitle); // Find the corresponding movie

  if (movie) {
    movie.seats += 1; // Restore the seat for the cancelled booking
  }

  bookings.splice(index, 1); // Remove the booking from the array

  // Send a success response indicating the booking has been cancelled
  res.json({ message: "Booking cancelled", booking: cancelledBooking });
});

// Start the server and listen on the specified port
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`); // Log the server URL
});